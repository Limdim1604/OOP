#pragma once
#include <bits/stdc++.h>

class ch {
protected:
    int type;

public:
    ch(int);
    virtual ~ch();

    virtual void nhap() = 0; 
    virtual double Sbm() = 0;
    virtual double V() = 0;   
};
