#pragma once
#include "ch.h"
#include <bits/stdc++.h>
using namespace std;


class chht : public ch {
private:
    double rht, hht;

public:
    chht();
    virtual ~chht();

    void nhap() override;
    double Sbm() override;
    double V() override;
};


