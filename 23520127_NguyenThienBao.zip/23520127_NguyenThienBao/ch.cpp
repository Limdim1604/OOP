#include <bits/stdc++.h>
#include "ch.h"
using namespace std;

ch:: ch(int t) {
    type = t;
}

ch:: ~ch() {
}
