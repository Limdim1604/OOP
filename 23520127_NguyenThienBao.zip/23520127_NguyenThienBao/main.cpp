#include "chht.h"
#include "chhhcn.h"
#include "chhc.h"
#include <bits/stdc++.h>

using namespace std;

int main() {
    int n;
    cin >> n;

    vector<ch*> danhsachchai;
    for (int i = 0; i < n; i++) {
        int type;
        cin >> type;

        ch* chai = nullptr;
        if (type == 1) {
            chai = new chhc();
        } else if (type == 2) {
            chai = new chhhcn();
        } else if (type == 3) {
            chai = new chht();
        } else {
            continue;
        }

        chai->nhap();
        danhsachchai.push_back(chai);
    }

    double tongdientich = 0;
    for (auto chai : danhsachchai) {
        tongdientich += chai->Sbm();
    }
    cout << "tong dien tich tren san la: " << tongdientich << endl;


    double tongronglai = 0;
    for (auto chai : danhsachchai) {
        if (dynamic_cast<chhc*>(chai)) {
            tongronglai += chai->V() * 0.305; 
        } else if (dynamic_cast<chhhcn*>(chai)) {
            tongronglai += chai->V() * 0.4;   
        } else if (dynamic_cast<chht*>(chai)) {
            tongronglai += chai->V() * 0.315; 
        }
    }
    cout << tongronglai << endl;


    for (auto chai : danhsachchai) {
        delete chai;
    }

    return 0;
};