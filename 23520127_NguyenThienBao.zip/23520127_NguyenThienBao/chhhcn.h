#pragma once
#include "ch.h"
#include <bits/stdc++.h>
using namespace std;


class chhhcn : public ch {
private:
    double l, w, h;

public:
    chhhcn();
    virtual ~chhhcn();

    void nhap() override;
    double Sbm() override;
    double V() override;
};
