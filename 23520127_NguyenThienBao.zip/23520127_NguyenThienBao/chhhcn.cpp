#include <bits/stdc++.h>
#include "chhhcn.h"
using namespace std;


chhhcn::chhhcn() : ch(2), l(0), w(0), h(0) {}

void chhhcn::nhap() {
    cin >> l >> w >> h;
}

double chhhcn::Sbm() {
    return 2 * (l * w + w * h + h * l);
}

double chhhcn::V() {
    return l * w * h;
}

chhhcn:: ~chhhcn() {
}