#include <bits/stdc++.h>
#include "chht.h"
using namespace std;


chht::chht() : ch(3), rht(0), hht(0) {}

void chht::nhap() {
    cin >> rht >> hht;
}

double chht::Sbm() {
    return 2 * 3.14 * rht * (rht + hht);
}

double chht::V() {
    return 3.14 * rht * rht * hht;
}

chht:: ~chht() {
}