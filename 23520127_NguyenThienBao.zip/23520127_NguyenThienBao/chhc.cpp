#include <bits/stdc++.h>
#include "chhc.h"
using namespace std;

chhc::chhc() : ch(1), r(0) {}

void chhc::nhap() {
    cin >> r;
}

double chhc::Sbm() {
    return 4 * 3.14 * r * r;
}

double chhc::V() {
    return (4.0 / 3) * 3.14 * r * r * r;
}

chhc:: ~chhc() {
}