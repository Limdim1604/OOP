#pragma once
#include "ch.h"
#include <bits/stdc++.h>
using namespace std;

class chhc : public ch {
private:
    double r;

public:
    chhc();
    virtual ~chhc();

    void nhap() override;
    double Sbm() override;
    double V() override;
};

